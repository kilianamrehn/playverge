VERGE PRESSEKIT
Opdateret: november 2026

Verge er et kortspil til mobilen for grupper, der helt naturligt udvikler sig fra legende til intimt, så langt hver person har lyst til. Live på iOS og Android siden 21. august 2026, fra 18 år.

INDHOLD
01_Logo            Logo og ordmærke, lyst og mørkt, transparent og som billede
02_Vivi            Vivi, Verges joker, fritlagt og på mørk baggrund
03_Screenshots     Otte skærmbilleder fra appen på dette sprog
04_Packs           Otte pakker, kvadratiske og på højkant med beskrivelse
05_Founder         Kilian, højformat, tværformat og kvadratisk
06_Article_Images  Tværformat 16:9 til artikelbilleder, lyst og mørkt
07_Pitch           Verge-pitchen som pdf, tre sider

BRUG
Alle filer må frit bruges til omtale, opslag og samarbejder. Bare én ting: Lad gerne logoet være, som det er.

KONTAKT
Kilian, kilian@playverge.app
playverge.app
