VERGE PRESS KIT
As of November 2026

Verge is a group card game for your phone that grows naturally from playful to intimate, as far as each person wants. Live on iOS and Android since 21 August 2026, 18+.

CONTENTS
01_Logo            Logo and wordmark, light and dark, transparent and as images
02_Vivi            Vivi, Verge’s joker, cut out and on a dark background
03_Screenshots     Eight screens from the app in this language
04_Packs           Eight packs, square and portrait with descriptions
05_Founder         Kilian, portrait, landscape and square
06_Article_Images  16:9 landscape for article images, light and dark
07_Pitch           The Verge pitch as a PDF, three pages

USAGE
All files are free to use for coverage, posts and collaborations. Just one request: please don’t alter the logo.

CONTACT
Kilian, kilian@playverge.app
playverge.app
