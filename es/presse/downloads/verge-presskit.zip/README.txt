KIT DE PRENSA DE VERGE
Actualizado: noviembre de 2026

Verge es una app de juego de cartas para grupos que pasa de forma natural de lo lúdico a lo íntimo, hasta donde cada persona quiera. Disponible desde el 21 de agosto de 2026 para iOS y Android, a partir de 18 años.

CONTENIDO
01_Logo            Logo y logotipo de texto, claro y oscuro, transparente y en imagen
02_Vivi            Vivi, la carta comodín de Verge, sin fondo y sobre fondo oscuro
03_Screenshots     Ocho pantallas de la app en este idioma
04_Packs           Ocho barajas, en formato cuadrado y vertical con descripción
05_Founder         Kilian, vertical, horizontal y cuadrado
06_Article_Images  Formato 16:9 para artículos, claro y oscuro
07_Pitch           El pitch de Verge en PDF, tres páginas

USO
Todos los archivos se pueden usar libremente para artículos, publicaciones y colaboraciones. Solo una petición: no modifiquen el logo.

CONTACTO
Kilian, kilian@playverge.app
playverge.app
