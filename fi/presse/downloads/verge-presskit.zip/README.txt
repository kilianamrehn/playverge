VERGE PRESSIPAKETTI
Päivitetty: marraskuu 2026

Verge on puhelimella pelattava ryhmäkorttipeli, joka etenee luontevasti leikkisästä intiimiin niin pitkälle kuin kukin haluaa. Saatavilla iOS:lle ja Androidille 21.8.2026 alkaen, K-18.

SISÄLTÖ
01_Logo            Logo ja sanamerkki, vaalea ja tumma, läpinäkyvä ja kuvana
02_Vivi            Vivi, Verge-pelin jokeri, taustasta irrotettuna ja tummaa taustaa vasten
03_Screenshots     Kahdeksan näkymää sovelluksesta tällä kielellä
04_Packs           Kahdeksan pakkaa, neliönä ja pystykuvana kuvauksen kanssa
05_Founder         Kilian, pysty, vaaka ja neliö
06_Article_Images  Vaakakuvat 16:9 artikkelikuviksi, vaalea ja tumma
07_Pitch           Verge-pitch PDF-tiedostona, kolme sivua

KÄYTTÖ
Kaikkia tiedostoja saa käyttää vapaasti uutisointiin, julkaisuihin ja yhteistyöhön. Yksi pyyntö: älkää muuttako logoa.

YHTEYSTIEDOT
Kilian, kilian@playverge.app
playverge.app
