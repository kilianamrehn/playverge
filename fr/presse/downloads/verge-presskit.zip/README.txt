KIT PRESSE VERGE
Version : novembre 2026

Verge est un jeu de cartes pour groupes, sur téléphone, qui passe naturellement du ludique à l’intime, aussi loin que chaque personne le souhaite. En ligne depuis le 21 août 2026 sur iOS et Android, 18 ans et plus.

CONTENU
01_Logo            Logo et logotype, clair et sombre, sur fond transparent et en image
02_Vivi            Vivi, la joker de Verge, détourée et sur fond sombre
03_Screenshots     Huit captures d’écran de l’appli dans cette langue
04_Packs           Huit packs, format carré et vertical avec description
05_Founder         Kilian, en portrait, paysage et carré
06_Article_Images  Format 16:9 pour visuels d’article, clair et sombre
07_Pitch           Le pitch Verge en PDF, trois pages

UTILISATION
Tous les fichiers sont libres d’utilisation pour des articles, des posts et des partenariats. Une seule demande : merci de ne pas modifier le logo.

CONTACT
Kilian, kilian@playverge.app
playverge.app
