VERGE FJÖLMIÐLAPAKKI
Uppfært: nóvember 2026

Verge er hópspil í símanum sem þróast á eðlilegan hátt frá léttum leik yfir í nánd, eins langt og hver manneskja vill. Í boði fyrir iOS og Android frá 21. ágúst 2026, 18 ára aldurstakmark.

EFNI
01_Logo            Merki og orðmerki, ljóst og dökkt, gegnsætt og sem mynd
02_Vivi            Vivi, jókerinn í Verge, án bakgrunns og á dökkum grunni
03_Screenshots     Átta skjámyndir úr appinu á þessu tungumáli
04_Packs           Átta pakkar, ferningslaga og á hæðina með lýsingu
05_Founder         Kilian, á hæðina, á breiddina og ferningslaga
06_Article_Images  Lárétt 16:9 fyrir greinarmyndir, ljóst og dökkt
07_Pitch           Verge-kynningin sem PDF, þrjár síður

NOTKUN
Allar skrár má nota frjálst í umfjöllun, færslur og samstarf. Ein bón: ekki breyta merkinu.

SAMBAND
Kilian, kilian@playverge.app
playverge.app
