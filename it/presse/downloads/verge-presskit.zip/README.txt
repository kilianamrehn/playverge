PRESS KIT DI VERGE
Aggiornato a novembre 2026

Verge è un gioco di carte di gruppo per smartphone che passa in modo naturale dalla leggerezza all’intimità, fin dove ogni persona vuole. Online dal 21 agosto 2026 per iOS e Android, dai 18 anni.

CONTENUTO
01_Logo            Logo e logotipo, chiaro e scuro, trasparente e come immagine
02_Vivi            Vivi, la carta jolly di Verge, scontornata e su sfondo scuro
03_Screenshots     Otto schermate dell’app in questa lingua
04_Packs           Otto mazzi, in formato quadrato e verticale con descrizione
05_Founder         Kilian, verticale, orizzontale e quadrato
06_Article_Images  Formato orizzontale 16:9 per articoli, chiaro e scuro
07_Pitch           Il pitch di Verge in PDF, tre pagine

UTILIZZO
Tutti i file si possono usare liberamente per articoli, servizi, post e collaborazioni. Una richiesta: non modificate il logo, grazie.

CONTATTI
Kilian, kilian@playverge.app
playverge.app
