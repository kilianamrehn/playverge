VERGE PERSKIT
Bijgewerkt: november 2026

Verge is een kaartspel voor groepen op je telefoon dat zich vanzelf ontwikkelt van speels naar intiem, zo ver als ieder wil. Sinds 21 augustus 2026 live voor iOS en Android, vanaf 18 jaar.

INHOUD
01_Logo            Logo en woordmerk, licht en donker, transparant en als afbeelding
02_Vivi            Vivi, de joker van Verge, uitgesneden en op een donkere achtergrond
03_Screenshots     Acht schermen uit de app in deze taal
04_Packs           Acht packs, vierkant en staand met beschrijving
05_Founder         Kilian, staand, liggend en vierkant
06_Article_Images  Liggend 16:9 voor artikelafbeeldingen, licht en donker
07_Pitch           De pitch van Verge als pdf, drie pagina’s

GEBRUIK
Alle bestanden mogen vrij worden gebruikt voor berichtgeving, posts en samenwerkingen. Eén verzoek: verander het logo alsjeblieft niet.

CONTACT
Kilian, kilian@playverge.app
playverge.app
