VERGE PRESSEMAPPE
Oppdatert: november 2026

Verge er et kortspill for grupper på mobilen, som utvikler seg naturlig fra lekent til intimt, så langt hver person vil. Tilgjengelig for iOS og Android siden 21. august 2026, aldersgrense 18 år.

INNHOLD
01_Logo            Logo og ordmerke, lys og mørk variant, transparent og som bilde
02_Vivi            Vivi, jokeren i Verge, frilagt og på mørk bakgrunn
03_Screenshots     Åtte skjermbilder fra appen på dette språket
04_Packs           Åtte pakker, kvadratisk og stående med beskrivelse
05_Founder         Kilian, stående, liggende og kvadratisk
06_Article_Images  Liggende 16:9 til artikkelbilder, lys og mørk variant
07_Pitch           Verge-pitchen som PDF, tre sider

BRUK
Alle filene kan brukes fritt til omtale, innlegg og samarbeid. Én ting ber vi om: Ikke endre logoen.

KONTAKT
Kilian, kilian@playverge.app
playverge.app
