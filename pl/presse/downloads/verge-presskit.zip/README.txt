MATERIAŁY PRASOWE VERGE
Stan na listopad 2026

Verge to grupowa gra karciana na telefon, która naturalnie przechodzi od zabawy do intymności, tak daleko, jak chce każda osoba. Na rynku od 21 sierpnia 2026, na iOS i Androida, od 18 lat.

ZAWARTOŚĆ
01_Logo            Logo i logotyp, jasne i ciemne, z przezroczystym tłem i jako obraz
02_Vivi            Vivi, jokerka z Verge, bez tła i na ciemnym tle
03_Screenshots     Osiem ekranów z aplikacji w tym języku
04_Packs           Osiem talii, kwadratowe i pionowe z opisem
05_Founder         Kilian, zdjęcia pionowe, poziome i kwadratowe
06_Article_Images  Grafiki poziome 16:9 do artykułów, jasne i ciemne
07_Pitch           Pitch Verge w PDF, trzy strony

UŻYCIE
Wszystkie pliki są do swobodnego użytku w publikacjach, postach i przy współpracy. Jedna prośba: prosimy nie zmieniać logo.

KONTAKT
Kilian, kilian@playverge.app
playverge.app
