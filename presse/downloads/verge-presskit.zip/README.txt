VERGE PRESSEKIT
Stand: November 2026

Verge ist ein Gruppenkartenspiel fürs Handy, das sich organisch von spielerisch zu intim entwickelt, so weit, wie jede Person möchte. Live seit dem 21. August 2026 für iOS und Android, ab 18.

INHALT
01_Logo            Logo und Wortmarke, hell und dunkel, transparent und als Bild
02_Vivi            Vivi, die Jokerin von Verge, freigestellt und auf dunklem Grund
03_Screenshots     Acht Bildschirme aus der App in dieser Sprache
04_Packs           Acht Packs, quadratisch und hochkant mit Beschreibung
05_Gruenderfoto    Kilian, hoch, quer und quadratisch
06_Artikelbilder   Querformat 16:9 für Artikelbilder, hell und dunkel
07_Pitch           Der Verge-Pitch als PDF, drei Seiten

NUTZUNG
Alle Dateien dürfen frei für Berichterstattung, Posts und Kooperationen verwendet werden. Eine Bitte: das Logo bitte nicht verändern.

KONTAKT
Kilian, kilian@playverge.app
playverge.app
