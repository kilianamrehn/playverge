KIT DE IMPRENSA DO VERGE
Versão de novembro de 2026

O Verge é uma app de cartas para grupos que evolui de forma natural da brincadeira até à intimidade, até onde cada pessoa quiser. Disponível em iOS e Android desde 21 de agosto de 2026, para maiores de 18 anos.

CONTEÚDO
01_Logo            Logo e versão só com o nome, claro e escuro, transparente e em imagem
02_Vivi            Vivi, a joker do Verge, recortada e sobre fundo escuro
03_Screenshots     Oito ecrãs da app neste idioma
04_Packs           Oito baralhos, em quadrado e na vertical com descrição
05_Founder         Kilian, vertical, horizontal e quadrado
06_Article_Images  Formato 16:9 para imagens de artigos, claro e escuro
07_Pitch           O pitch do Verge em PDF, três páginas

UTILIZAÇÃO
Todos os ficheiros podem ser usados livremente em notícias, posts e parcerias. Só um pedido: não alterem o logo, por favor.

CONTACTO
Kilian, kilian@playverge.app
playverge.app
