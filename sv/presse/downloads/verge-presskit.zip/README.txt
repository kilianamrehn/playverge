VERGE PRESSKIT
Uppdaterad: november 2026

Verge är ett kortspel för grupper i mobilen som utvecklas naturligt från lekfullt till intimt, så långt som var och en vill. Live för iOS och Android sedan 21 augusti 2026, från 18 år.

INNEHÅLL
01_Logo            Logotyp och ordmärke, ljus och mörk, transparent och som bild
02_Vivi            Vivi, Verges joker, frilagd och på mörk bakgrund
03_Screenshots     Åtta skärmar från appen på det här språket
04_Packs           Åtta paket, kvadratiska och stående med beskrivning
05_Founder         Kilian, stående, liggande och kvadratisk
06_Article_Images  Liggande 16:9 för artikelbilder, ljus och mörk
07_Pitch           Verge-pitchen som pdf, tre sidor

ANVÄNDNING
Alla filer får användas fritt för bevakning, inlägg och samarbeten. En sak bara: ändra inte logotypen.

KONTAKT
Kilian, kilian@playverge.app
playverge.app
